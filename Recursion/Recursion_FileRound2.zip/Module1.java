import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class Module1 {
    /**
     * Hàm {@code pipeline(numbers, size)} trả về các số bị thiếu trong đoạn
     * từ [0, size-1].
     * Ví dụ: {@code (pipeline([0, 1, 2, 5, 6], 7) == [3, 4]}
     * @param numbers
     * @param size
     * @return trả về các số bị thiếu trong đoạn từ [0, size-1]
     */
    public static List<Integer> pipeline(List<Integer> numbers, int size) {
        List<Integer> result = new ArrayList<Integer>();
        return result;
    }
}
import java.util.ArrayList;
import java.util.List;

public class Module2 {
    /**
     * Hàm {@code pipeline(numbers)} trả về số bộ ba số có tổng cộng lại chia hết cho 3.
     * Ví dụ: {@code (pipeline([1, 2, 3, 4, 7]) == 4}.
     *
     * @param numbers mảng danh sách các số cần xét.
     * @return số bộ ba số có tổng cộng lại chia hết cho 3.
     */
    public static int pipeline(List<Integer> numbers) {
        int count = 0;
        return count;
    }
}

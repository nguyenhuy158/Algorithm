import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;

public class Main {
    public static void main(String[] args) {
        List<Integer> data = Utils.readFile(args[0]);
        int size = data.remove(0);

        long startTime;
        long endTime;
        long timeElapsed;
        List<Integer> output1;
        int output2;

        startTime = System.nanoTime();
        try {
            output1 = CompletableFuture.supplyAsync((Supplier<List<Integer>>) () -> Module1.pipeline(data, size))
                    .get(10, TimeUnit.SECONDS);
        } catch (TimeoutException | InterruptedException | ExecutionException e) {
            System.err.println("Time out has occurred");
            output1 = null;
        }
        final List<Integer> input2 = output1;
        endTime = System.nanoTime();
        timeElapsed = endTime - startTime;
        System.out.printf("Pipeline 1 - execution time in: %d nanoseconds ~ %.6f milliseconds ~ %.9f seconds \n",
                timeElapsed, (float) timeElapsed / 1000000, (float) timeElapsed / 1000000000);

        startTime = System.nanoTime();
        try {
            output2 = CompletableFuture.supplyAsync((Supplier<Integer>) () -> Module2.pipeline(input2)).get(10,
                    TimeUnit.SECONDS);
        } catch (TimeoutException | InterruptedException | ExecutionException e) {
            System.err.println("Time out has occurred");
            output2 = -1;
        }
        endTime = System.nanoTime();
        timeElapsed = endTime - startTime;
        System.out.printf("Pipeline 2 - execution time in: %d nanoseconds ~ %.6f milliseconds ~ %.9f seconds \n",
                timeElapsed, (float) timeElapsed / 1000000, (float) timeElapsed / 1000000000);
    }
}

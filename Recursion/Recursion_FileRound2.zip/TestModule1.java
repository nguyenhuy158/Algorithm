import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;
import java.util.concurrent.ExecutionException;

public class TestModule1 {
    public static void main(String[] args) {
        List<Integer> data = Utils.readFile(args[0]);
        int size = data.remove(0);

        long startTime = System.nanoTime();
        List<Integer> result;
        try {
            result = CompletableFuture.supplyAsync((Supplier<List<Integer>>) () -> Module1.pipeline(data, size)).get(10, TimeUnit.SECONDS);
        } catch (TimeoutException | InterruptedException | ExecutionException e) {
            System.err.println("Time out has occurred");
            result = null;
        }
        long endTime = System.nanoTime();
        long timeElapsed = endTime - startTime;

        System.out.printf("Execution time in: %d nanoseconds ~ %.6f milliseconds ~ %.9f seconds \n", timeElapsed, (float) timeElapsed / 1000000, (float) timeElapsed / 1000000000);
    }
}

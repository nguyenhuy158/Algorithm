import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Utils {
    public static List<Integer> readFile(String filepath) {
        List<Integer> data = new ArrayList<Integer>();
        try {
            Scanner sc = new Scanner(new File(filepath));
            while (sc.hasNextLine()) {
                Integer num = Integer.parseInt(sc.nextLine());
                data.add(num);
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return data;
    }
}

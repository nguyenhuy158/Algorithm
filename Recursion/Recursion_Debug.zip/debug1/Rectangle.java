public class Rectangle {
    protected double length;
    protected double width;

    public Rectangle(double width, double length) {
        this.length = length;
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getPerimeter() {
        return (this.length + this.width) * 2;
    }

    public double getArea() {
        return this.length * this.width;
    }

    @Override
    public String toString() {
        return String.format("Rectangle[width=%.2f, length=%.2f]", this.width, this.length);
    }
}

public class Main {
    public static void main(String[] args) {
        Square s1 = new Square(5.);
        s1.setWidth(6.);
        if (s1.getArea() == 6. * 6.)
            System.out.println("Correct");
        else
            System.out.println("Incorrect");

        Square s2 = new Square(5.);
        s2.setLength(7.);
        if (s2.getArea() == 7. * 7.)
            System.out.println("Correct");
        else
            System.out.println("Incorrect");
    }
}

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static String readFile(String filepath) {
        try {
            String line = "";
            File file = new File(filepath);
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                line = sc.nextLine();
                break;
            }
            sc.close();
            return line;
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        String str = readFile(args[0]);
        BinaryTree tree = new BinaryTree(str);
        System.out.println("Input: " + str);
        System.out.println("Output: " + tree.toString());
        if (str.equals(tree.toString()))
            System.out.println("Correct");
        else
            System.out.println("Incorrect");
    }
}

public class BinaryTree {
	private Node root;

	public BinaryTree(String str) {
		this.root = str2tree(str);
	}

	public BinaryTree(Node root) {
		this.root = root;
	}

	@Override
	public String toString() {
		return tree2str(root);
	}

	public String tree2str(Node node) {
		if (node == null)
			return "N";
		if (node.getLeft() == null && node.getRight() == null)
			return String.format("%s", node.getData());
		return String.format("%s (%s %s)", node.getData(), tree2str(node.getLeft()), tree2str(node.getRight()));
	}

	public static Node str2tree(String str) {
		if (str == null || str.length() == 0) {
			return null;
		}
		int idxLeftParentheses = str.indexOf("(");
		if (idxLeftParentheses != -1) {
			int value = Integer.parseInt(str.substring(0, idxLeftParentheses - 1));
			String childNodes = str.substring(idxLeftParentheses + 1, str.length() - 1);
			Node root = new Node();
			root.setData(value);
			String leftNode = childNodes.substring(0, childNodes.indexOf(' '));
			String rightNode = childNodes.substring(childNodes.indexOf(' ') + 1);
			root.setLeft(str2tree(leftNode));
			root.setRight(str2tree(rightNode));
			return root;
		} else {
			if (str.equals("N")) {
				return null;
			}
			int value = Integer.parseInt(str);
			Node root = new Node();
			root.setData(value);
			return root;
		}
	}
}
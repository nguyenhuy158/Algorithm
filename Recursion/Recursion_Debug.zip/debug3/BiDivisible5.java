public class BiDivisible5 {
    public static boolean biDivisible5(String binary) {
        int lastDigitDec = 0;
        for (int i = 0; i < binary.length(); i++) {
            if (binary.charAt(i) == '1') {
                switch (i%4) {
                    case 0:
                        lastDigitDec += 6; // n % 4 == 0 -> lastDigit(2^n) = 6 with n != 0
                        break;
                    case 1:
                        lastDigitDec += 2; // n % 4 == 1 -> lastDigit(2^n) = 2
                        break;
                    case 2:
                        lastDigitDec += 4; // n % 4 == 2 -> lastDigit(2^n) = 4
                        break;
                    case 3:
                        lastDigitDec += 8; // n % 4 == 3 -> lastDigit(2^n) = 8
                        break;
                    default:
                        break;
                }
                lastDigitDec %= 10;
            }
        }
        return lastDigitDec == 0 || lastDigitDec == 5;
    }
}

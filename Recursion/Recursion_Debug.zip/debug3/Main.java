import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static String[] readFile(String filepath) {
        String[] lines = {"", ""};
        try {
            File file = new File(filepath);
            Scanner sc = new Scanner(file);
            int count = 0;
            while (sc.hasNextLine()) {
                lines[count] = sc.nextLine();
                count++;
                if (count == 2) break;
            }
            sc.close();
            return lines;
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        String[] lines = readFile(args[0]);
        System.out.println("Dec: " + lines[0]);
        System.out.println("Bin: " + lines[1]);
        if (BiDivisible5biDivisible5(lines[1]) && (lines[0].charAt(lines[0].length() - 1) == '0' || lines[0].charAt(lines[0].length() - 1) == '5'))
            System.out.println("Correct");
        else
            System.out.println("Incorrect");
    }
}

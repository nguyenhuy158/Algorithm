import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static String[] readFile(String filepath) {
        String[] lines = {"", ""};
        try {
            File file = new File(filepath);
            Scanner sc = new Scanner(file);
            int count = 0;
            while (sc.hasNextLine()) {
                lines[count] = sc.nextLine();
                count++;
                if (count == 2) break;
            }
            sc.close();
            return lines;
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            return null;
        }
    }
    public static void main(String[] args) {
        double EPSILON = Root.EPSILON;

        String[] lines = readFile(args[0]);
        int num1 = Integer.parseInt(lines[0]);
        double num2 = Double.parseDouble(lines[1]);

        System.out.printf("square_root(%d) = %.15f\n", num1, Root.square_root(num1));
        System.out.printf("cube_root(%d) = %.15f\n", num1, Root.cube_root(num1));
        if (Root.absolute(Root.cube_root(num1) - num2) < EPSILON)
            System.out.println("Correct");
        else
            System.out.println("Incorrect");
    }
}

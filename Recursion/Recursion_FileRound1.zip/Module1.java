import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.regex.Pattern;

public class Module1 {
    public static List<String> tokenize(String str) {
        String[] arrStrings = str.split(" ");
        return Arrays.asList(arrStrings);
    }

    public static boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
        if (str == null) {
            return false;
        }
        return pattern.matcher(str).matches();
    }

    public static boolean isOperator(String str) {
        Pattern pattern = Pattern.compile("[\\+\\-\\*\\/\\^]");
        if (str == null) {
            return false;
        }
        return pattern.matcher(str).matches();
    }

    public static boolean isLeftAssociative(String str) {
        return !str.equals("^");
    }

    public static int getPrecedence(String str) {
        if (str.equals("^"))
            return 4;
        else if (str.equals("*"))
            return 3;
        else if (str.equals("/"))
            return 3;
        else if (str.equals("+"))
            return 2;
        else if (str.equals("-"))
            return 2;
        return 1;
    }

    public static boolean isLeftParenthesis(String str) {
        return str.equals("(");
    }

    public static boolean isRightParenthesis(String str) {
        return str.equals(")");
    }

    public static List<String> infixToPostfix(List<String> infix) {
        List<String> queue = new ArrayList<String>();
        Stack<String> stack = new Stack<String>();
        /** Hoàn thiện code ở đây */
        /** Bạn có thể tham khảo ở đây: https://en.wikipedia.org/wiki/Shunting-yard_algorithm */
        /** Bạn nhớ xoá dòng này, dòng này để Main ko bị lỗi */queue.add(infix.get(0));
        return queue;
    }

    public static BinaryTree str2tree(String str) {
        List<String> infix = tokenize(str);
        List<String> postfix = infixToPostfix(infix);

        Stack<Node> stack = new Stack<Node>();

        for (String token : postfix) {
            if (isNumeric(token)) {
                Node number = new Node(token);
                stack.push(number);
            }
            if (isOperator(token)) {
                Node operator = new Node(token);
                Node operand2 = stack.pop();
                Node operand1 = stack.pop();
                operator.setRight(operand2);
                operator.setLeft(operand1);
                stack.push(operator);
            }
        }
        return new BinaryTree(stack.pop());
    }
}
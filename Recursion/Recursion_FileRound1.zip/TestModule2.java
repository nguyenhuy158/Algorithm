public class TestModule2 {
    /* Không cần quan tâm phương thức này */
	/* Không cần quan tâm phương thức này */public static Node method(String str) {
	/* Không cần quan tâm phương thức này */if (str == null || str.length() == 0) {
	/* Không cần quan tâm phương thức này */return null;}
	/* Không cần quan tâm phương thức này */int bar = str.indexOf("(");
	/* Không cần quan tâm phương thức này */if (bar != -1) {
	/* Không cần quan tâm phương thức này */String baz = str.substring(0, bar - 1);
	/* Không cần quan tâm phương thức này */String foobar = str.substring(bar + 1, str.length() - 1);
	/* Không cần quan tâm phương thức này */Node root = new Node(baz);
	/* Không cần quan tâm phương thức này */int foobaz = foobar.indexOf(" ");
	/* Không cần quan tâm phương thức này */bar = foobar.indexOf("(");
	/* Không cần quan tâm phương thức này */if (foobaz + 1 == bar) {
	/* Không cần quan tâm phương thức này */int c = 0;
	/* Không cần quan tâm phương thức này */for (int i = 0; i < foobar.length(); i++) {
	/* Không cần quan tâm phương thức này */if (foobar.charAt(i) == '(') {
	/* Không cần quan tâm phương thức này */c++;
	/* Không cần quan tâm phương thức này */} else if (foobar.charAt(i) == ')') {
	/* Không cần quan tâm phương thức này */c--;
	/* Không cần quan tâm phương thức này */if (c == 0) {
	/* Không cần quan tâm phương thức này */String boo = foobar.substring(0, i + 1);
	/* Không cần quan tâm phương thức này */String poo = foobar.substring(i + 2);
	/* Không cần quan tâm phương thức này */root.setLeft(method(boo));
	/* Không cần quan tâm phương thức này */root.setRight(method(poo));
	/* Không cần quan tâm phương thức này */return root;
	/* Không cần quan tâm phương thức này */}}}} else {
	/* Không cần quan tâm phương thức này */String boo = foobar.substring(0, foobar.indexOf(' '));
	/* Không cần quan tâm phương thức này */String poo = foobar.substring(foobar.indexOf(' ') + 1);
	/* Không cần quan tâm phương thức này */root.setLeft(method(boo));
	/* Không cần quan tâm phương thức này */root.setRight(method(poo));
	/* Không cần quan tâm phương thức này */return root;
	/* Không cần quan tâm phương thức này */}} else {
	/* Không cần quan tâm phương thức này */if (str.equals("N")) {
	/* Không cần quan tâm phương thức này */return null;}
	/* Không cần quan tâm phương thức này */Node root = new Node(str);
	/* Không cần quan tâm phương thức này */return root;}
	/* Không cần quan tâm phương thức này */return null;}

    public static void main(String[] args) {
        String[] lines = Utils.readFile(args[0]);
        Node root = method(lines[1]);
        BinaryTree tree = new BinaryTree(root);
        if (Math.abs(Module2.calculate(tree) - Double.parseDouble(lines[2])) < 0.000001)
            System.out.println("Module2: Correct");
        else
            System.out.println("Module2: Incorrect");
    }
}

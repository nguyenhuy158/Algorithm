public class Module2 {
    public static double calculate(BinaryTree tree) {
        return calculate(tree.getRoot());
    }

    public static double calculate(Node node) {
        /** Hoàn thiện code ở đây */
        return 0.0;
    }
}
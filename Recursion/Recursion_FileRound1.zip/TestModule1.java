public class TestModule1 {
    public static void main(String[] args) {
        String[] lines = Utils.readFile(args[0]);
        BinaryTree tree = Module1.str2tree(lines[0]);
        if (tree.toString().equals(lines[1]))
            System.out.println("Module1: Correct");
        else
            System.out.println("Module1: Incorrect");
    }
}

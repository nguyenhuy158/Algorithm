import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Utils {
    public static String[] readFile(String filepath) {
        String[] lines = {"", "", ""};
        try {
            File file = new File(filepath);
            Scanner sc = new Scanner(file);
            int count = 0;
            while (sc.hasNextLine()) {
                lines[count] = sc.nextLine();
                count++;
                if (count == 3) break;
            }
            sc.close();
            return lines;
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            return null;
        }
    }
}

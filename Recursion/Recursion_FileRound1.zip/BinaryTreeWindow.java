// Reference: https://www.ecs.csun.edu/~cputnam/Comp%20110/Liang%208th%20ed%20PP_Slides/html/BinaryTreeView.html

import java.awt.*;
import javax.swing.*;

public class BinaryTreeWindow extends JFrame {
    private BinaryTree tree; // A binary tree to be displayed
    private PaintTree paintTree;
    private JPanel view;

    /** Construct a view for a binary tree */
    public BinaryTreeWindow(BinaryTree tree) {
        this.tree = tree; // Set a binary tree to be displayed
        prepareGUI();
    }

    /** Initialize UI for binary tree */
    private void prepareGUI() {
        this.setSize(800, 600);
        view = new JPanel();
        view.setLayout(new BorderLayout());
        view.add(new PaintTree(), BorderLayout.CENTER);
        this.add(view);
        this.setVisible(true);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    // Inner class PaintTree for displaying a tree on a panel
    class PaintTree extends JPanel {
        private int radius = 20; // Tree node radius
        private int vGap = 50; // Gap between two levels in a tree

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (tree.getRoot() != null) {
                // Display tree recursively
                displayTree(g, tree.getRoot(), getWidth() / 2, 30, getWidth() / 4);
            }
        }

        /** Display a subtree rooted at position (x, y) */
        private void displayTree(Graphics g, Node root, int x, int y, int hGap) {
            // Display the root
            g.drawOval(x - radius, y - radius, 2 * radius, 2 * radius);
            g.drawString(root.getData() + "", x - 6, y + 4);
            if (Module1.isOperator(root.getData())) {
                g.drawString(Module2.calculate(root) + "", x + 30, y + 4);
            }

            if (root.getLeft() != null) {
                // Draw a line to the left node
                connectLeftChild(g, x - hGap, y + vGap, x, y);
                // Draw the left subtree recursively
                displayTree(g, root.getLeft(), x - hGap, y + vGap, hGap / 2);
            }

            if (root.getRight() != null) {
                // Draw a line to the right node
                connectRightChild(g, x + hGap, y + vGap, x, y);
                // Draw the right subtree recursively
                displayTree(g, root.getRight(), x + hGap, y + vGap, hGap / 2);
            }
        }

        /**
         * Connect a parent at (x2, y2) with its left child at (x1, y1)
         */
        private void connectLeftChild(Graphics g, int x1, int y1, int x2, int y2) {
            double d = Math.sqrt(vGap * vGap + (x2 - x1) * (x2 - x1));
            int x11 = (int) (x1 + radius * (x2 - x1) / d);
            int y11 = (int) (y1 - radius * vGap / d);
            int x21 = (int) (x2 - radius * (x2 - x1) / d);
            int y21 = (int) (y2 + radius * vGap / d);
            g.drawLine(x11, y11, x21, y21);
        }

        /**
         * Connect a parent at (x2, y2) with its right child at (x1, y1)
         */
        private void connectRightChild(Graphics g, int x1, int y1, int x2, int y2) {
            double d = Math.sqrt(vGap * vGap + (x2 - x1) * (x2 - x1));
            int x11 = (int) (x1 - radius * (x1 - x2) / d);
            int y11 = (int) (y1 - radius * vGap / d);
            int x21 = (int) (x2 + radius * (x1 - x2) / d);
            int y21 = (int) (y2 + radius * vGap / d);
            g.drawLine(x11, y11, x21, y21);
        }
    }
}
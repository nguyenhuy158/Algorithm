import javax.swing.JFrame;
import javax.swing.WindowConstants;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String[] lines = Utils.readFile(args[0]);
        BinaryTree tree = Module1.str2tree(lines[0]);
        if (tree.toString().equals(lines[1]))
            System.out.println("Module1: Correct");
        else
            System.out.println("Module1: Incorrect");

        if (Math.abs(Module2.calculate(tree) - Double.parseDouble(lines[2])) < 0.000001)
            System.out.println("Module2: Correct");
        else
            System.out.println("Module2: Incorrect");
        BinaryTreeWindow view = new BinaryTreeWindow(tree);
    }
}

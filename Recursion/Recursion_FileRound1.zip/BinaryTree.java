public class BinaryTree {
    private Node root;

    public BinaryTree(Node root) {
        this.root = root;
    }

    public Node getRoot() {
        return root;
    }

    public void setRoot(Node root) {
        this.root = root;
    }

    public String tree2str(Node node) {
		if (node == null)
			return "N";
		if (node.getLeft() == null && node.getRight() == null)
			return String.format("%s", node.getData());
		return String.format("%s (%s %s)", node.getData(), tree2str(node.getLeft()), tree2str(node.getRight()));
	}

    @Override
    public String toString() {
        return tree2str(this.root);
    }
}